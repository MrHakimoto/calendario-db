<?php

$textin = $_POST["txt"];
$mat= $_POST["cmat"];

$maccabeus1="$mat : $textin <br>";

echo $maccabeus1;
?>

