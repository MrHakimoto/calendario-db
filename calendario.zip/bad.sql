CREATE DATABASE calendario

CREATE TABLE t_janeiro(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )

CREATE TABLE t_fevereiro(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_marco(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_abril(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_maio(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_junho(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_julho(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_agosto(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_setembro(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_outubro(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_novembro(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
    )
CREATE TABLE t_dezembro(
    day INT NOT NULL,
    Tarefa VARCHAR(50) NULL,
    Tarefa2 VARCHAR(50) NULL,
)